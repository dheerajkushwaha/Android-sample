package com.lilly.callisto.featuremodules.onboard.participantlogin;

import android.app.Application;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.lilly.callisto.comman.model.CredentialsResModel;
import com.lilly.callisto.comman.model.SignInReqModel;
import com.lilly.callisto.comman.model.SignInResModel;
import com.lilly.callisto.comman.model.UserResModel;
import com.lilly.callisto.data.cloud.CloudRepo;
import com.lilly.callisto.data.localDB.DatabaseRepository;
import com.lilly.callisto.utils.DeviceUtils;
import com.lilly.callisto.utils.NetworkUtil;

import io.reactivex.Single;
import io.reactivex.SingleObserver;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;

public class ParticipantLogInViewModel extends AndroidViewModel {

    private String mUserId;
    private String mPassword;
    private Application mApplication;
    private MutableLiveData<Boolean> mLoginStatus;
    private CompositeDisposable disposable = new CompositeDisposable();
    private LiveData<SignInResModel> signInResModelLiveData;
    private CloudRepo mCloudRepo;
    private DatabaseRepository mDatabaseRepository;
    private static final String TAG = "ParticipantLogInViewMod";

    public ParticipantLogInViewModel(@NonNull Application application) {

        super(application);
        mApplication = application;
        mLoginStatus = new MutableLiveData<Boolean>();
        mCloudRepo = new CloudRepo(application);
        mDatabaseRepository = new DatabaseRepository(application);

    }

    public String getUserId() {
        return mUserId;
    }

    public void setUserId(String userId) {
        mUserId = userId;
    }

    public String getPassword() {
        return mPassword;
    }

    public void setPassword(String password) {
        mPassword = password;
    }

    public void doLogin() {

        if (isUserIdPasswordValid() && NetworkUtil.isNetworkConnected(mApplication.getApplicationContext())) {
            Log.i("==", "internet conncted");
            SignInReqModel signInReqModel = new SignInReqModel();
            /*signInReqModel.setUsername("Participant77");
            signInReqModel.setPassword("Password123");
            */

            signInReqModel.setUsername(getUserId());
            signInReqModel.setPassword(getPassword());

            signInReqModel.setDevice_id(DeviceUtils.getUDID(mApplication.getApplicationContext()));
            CloudRepo cloudRepo = new CloudRepo(mApplication.getApplicationContext());
            Single<SignInResModel> signInResModelCall = cloudRepo.verifyUser(signInReqModel);

            signInResModelCall.subscribeOn(Schedulers.io());
            signInResModelCall.observeOn(AndroidSchedulers.mainThread());
            signInResModelCall.subscribe(new SingleObserver<SignInResModel>() {
                @Override
                public void onSubscribe(Disposable d) {
                    Log.i("onSubscribe", "onSubscribe");
                }

                @Override
                public void onSuccess(SignInResModel signIn) {
                    Log.i("onSuccess", "onSuccess");
                    insertLoginRecordinDB();
                    mLoginStatus.setValue(true);
                }

                @Override
                public void onError(Throwable e) {
                    Log.i("onError", "onError");
                    insertLoginRecordinDB();
                    mLoginStatus.setValue(false);
                }
            });
        }
    }

    private void getLoginRecord() {

        SignInResModel signInResModelFlowable = mDatabaseRepository.getLoginDetail();
        UserResModel userResModel = signInResModelFlowable.getUser();
        CredentialsResModel credentialsResModel = signInResModelFlowable.getCredentials();
    }

    private void insertLoginRecordinDB() {

        SignInResModel signIn = new SignInResModel();

        UserResModel userResModel = new UserResModel();
        userResModel.setId("1234");
        userResModel.setUsername("dheeraj");

        CredentialsResModel credentialsResModel = new CredentialsResModel();
        credentialsResModel.setToken("123456789");

        signIn.setUser(userResModel);
        signIn.setCredentials(credentialsResModel);
        // mDatabaseRepository.insertLoginDetail(signIn);

        mDatabaseRepository.insertLoginDetail(signIn);

    }

    private boolean isUserIdPasswordValid() {
        if (TextUtils.isEmpty(getUserId()) || TextUtils.isEmpty(getPassword())) {
            return false;
        }
        return true;
    }

    public MutableLiveData<Boolean> getLoginStatus() {
        return mLoginStatus;
    }
}