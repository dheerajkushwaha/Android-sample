package com.lilly.callisto.data.localDB.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.lilly.callisto.comman.model.SignInResModel;

import io.reactivex.Flowable;

@Dao
public interface LoginDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(SignInResModel resultModel);

    @Query("SELECT * from Login")
    SignInResModel getLoginDetail();

    @Query("DELETE FROM login")
    void deleteAll();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertLogin(SignInResModel resultModel);
}
