package com.lilly.callisto.data.cloud;

import android.content.Context;
import androidx.lifecycle.MutableLiveData;
import com.lilly.callisto.comman.model.SignInReqModel;
import com.lilly.callisto.comman.model.SignInResModel;
import io.reactivex.Single;
import io.reactivex.disposables.CompositeDisposable;

public class CloudRepo {

    private CloudApiService mCloudApiService;
    private MutableLiveData<SignInResModel> mUserResModelLiveData;
    private CompositeDisposable disposable = new CompositeDisposable();
    private Context mContext;

    public CloudRepo(Context context) {
        mCloudApiService = CloudManager.getClient(context).create(CloudApiService.class);
    }
    public Single<SignInResModel> verifyUser(SignInReqModel signInReqModel) {
       return mCloudApiService.signIn(signInReqModel);
    }
}
