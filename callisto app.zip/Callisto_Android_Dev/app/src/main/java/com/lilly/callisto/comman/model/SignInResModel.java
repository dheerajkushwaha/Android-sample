package com.lilly.callisto.comman.model;

import androidx.annotation.NonNull;
import androidx.room.Embedded;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Login")
public class SignInResModel {

    @PrimaryKey(autoGenerate = true)
    @NonNull
    public int id1;

    @Embedded
    private UserResModel user;
    @Embedded
    private CredentialsResModel credentials;

    public UserResModel getUser() {
        return user;
    }

    public CredentialsResModel getCredentials() {
        return credentials;
    }

    public void setUser(UserResModel user) {

        this.user = user;
    }

    public void setCredentials(CredentialsResModel credentials) {

        this.credentials = credentials;
    }
}
