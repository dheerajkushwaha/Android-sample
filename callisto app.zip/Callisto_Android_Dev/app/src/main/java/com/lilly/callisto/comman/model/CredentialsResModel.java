package com.lilly.callisto.comman.model;

import androidx.room.ColumnInfo;

public class CredentialsResModel {

    @ColumnInfo(name = "token")
    private String token;
    @ColumnInfo(name = "expires_at")
    private String expires_at;

    public String getToken() {
        return token;
    }
    public String getExpires_at() {
        return expires_at;
    }
    public void setToken(String token) {
        this.token = token;
    }
    public void setExpires_at(String expires_at) {
        this.expires_at = expires_at;
    }
}