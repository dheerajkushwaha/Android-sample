package com.lilly.callisto.data.localDB;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import com.lilly.callisto.comman.model.SignInResModel;
import com.lilly.callisto.data.localDB.dao.LoginDao;
import com.lilly.callisto.data.localDB.entities.ResultModel;

/**
 * This class is acts as interface to call Database to perform DB operation
 */

@Database(entities = {SignInResModel.class,}, version = 1,exportSchema = true)
public abstract class DataManager extends RoomDatabase {

    private static final String DB_NAME = "CallistoDb";
    private static DataManager instance;

    public abstract LoginDao loginDao();

    public synchronized static DataManager getInstance(final Context context) {
        if (instance == null) {
            synchronized (DataManager.class) {
                if (instance == null) {
                    instance = Room.databaseBuilder(context, DataManager.class, DB_NAME)
                            .allowMainThreadQueries().build();
                }
            }
        }
        return instance;
    }
}
