package com.lilly.callisto.featuremodules.onboard.termsandconditions;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.lilly.callisto.BR;
import com.lilly.callisto.R;
import com.lilly.callisto.base.BaseFragment;
import com.lilly.callisto.databinding.FragmentTermsAndConditionsBinding;

public class TermsAndConditionFragment extends BaseFragment<TermsAndConditionViewModel,
        FragmentTermsAndConditionsBinding> implements View.OnClickListener {
   private Button mAgreeButton;
   private TextView mDisAgreeTextView;
    @Override
    protected void initViews() {
        mAgreeButton = mViewDataBinding.buttonAgree;
        mDisAgreeTextView = mViewDataBinding.disagreeTv;
        mAgreeButton.setOnClickListener(this);
        mDisAgreeTextView.setOnClickListener(this);
    }

    @Override
    protected int getBindingVariable() {
        return BR.termsAndConditionsVM;
    }

    @Override
    protected Class getViewModelClass() {
        return TermsAndConditionViewModel.class;
    }

    @Override
    protected int getLayoutRef() {
        return R.layout.fragment_terms_and_conditions;
    }

    @Override
    public void onClick(View view) {
        if(view != null) {
            NavController navController = Navigation.findNavController(view);
            if(view.getId() == R.id.button_agree ){
                navController.navigate(R.id.action_terms_and_conditions_to_participate_login);
            } else if(view.getId() == R.id.disagree_tv) {
                navController.navigate(R.id.action_terms_and_conditions_to_signin);
            }
        }
    }
}
