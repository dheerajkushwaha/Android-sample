package com.lilly.callisto.utils;

import android.content.Context;
import android.provider.Settings;

public class DeviceUtils {
    public static String getUDID(Context context) {
        String mUDID = Settings.Secure.getString(context.getContentResolver(),
                Settings.Secure.ANDROID_ID);
        return  mUDID;
    }
}
