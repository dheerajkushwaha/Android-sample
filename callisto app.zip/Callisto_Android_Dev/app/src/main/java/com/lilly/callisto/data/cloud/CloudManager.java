package com.lilly.callisto.data.cloud;

import android.content.Context;

import com.jakewharton.retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.lilly.callisto.constants.CloudConstants.BASE_URL;
import static com.lilly.callisto.constants.CloudConstants.REQUEST_TIMEOUT;

/**
 * This class is acts as interface to perform cloud activities
 */
public class CloudManager {
    private static Retrofit retrofit = null;

    private CloudManager() {
    }
    private static final OkHttpClient okHttpClient = new OkHttpClient.Builder()
            .readTimeout(REQUEST_TIMEOUT, TimeUnit.MINUTES)
            .connectTimeout(REQUEST_TIMEOUT, TimeUnit.MINUTES)
            .build();

    public static Retrofit getClient(Context context) {
        synchronized (CloudManager.class) {
            if (retrofit == null) {
                retrofit = new Retrofit.Builder()
                        .baseUrl(BASE_URL)
                        .client(okHttpClient)
                        .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                        .addConverterFactory(GsonConverterFactory.create())
                        .build();
            }
        }
        return retrofit;
    }
}
