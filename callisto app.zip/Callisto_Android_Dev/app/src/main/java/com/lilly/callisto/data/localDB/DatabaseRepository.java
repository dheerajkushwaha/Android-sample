package com.lilly.callisto.data.localDB;

import android.app.Application;
import com.lilly.callisto.comman.model.SignInResModel;
import io.reactivex.Flowable;

public class DatabaseRepository {

    private DataManager dataManager;
    public  DatabaseRepository(Application application) {
        dataManager = DataManager.getInstance(application);
    }

    public void insertLoginDetail(SignInResModel signInResModel) {
       long status= dataManager.loginDao().insert(signInResModel);
    }

    public SignInResModel getLoginDetail() {
        return dataManager.loginDao().getLoginDetail();
    }

}

